# AAP Global Configuration as Code Repository

This repo contains the global configuration settings of the AAP Platform.

Content of this repo is solely accessible and managed by the Platform Administrators.

Before using this repo, please make sure the following prerequisites are met.

## Controller Global Configuration Folder Structure

```
controller_config/
  └── common
     ├── applications.d
     ├── credential_input_sources.d
     ├── credential_types.d
     ├── execution_environments.d
     ├── instance_groups.d
     ├── instances.d
     ├── notification_templates.d
     ├── organizations.d
     ├── roles.d
     ├── settings.d
     └── teams.d
```

## Repo Content

|Name|Type|Description|
|:---:|:---:|:---:|
|`controller_create_user_objects.yml`|Playbook|Creator of the yaml objects into AAP Controller|
|`ah_create_resources.yml`|Playbook|Creator of the yaml objects into AAP Automation Hub|
|`controller_clean_admin_objects.yml`|Playbook|Remover of any AAP object that is not declared in this git repo. This assure that the git repo remain the only source of truth|
|`controller_create_admin_objects.yml`|Playbook|Configure the platform settings (like authentication, logging, instances...) |
|`controller_extract_and_create_filetree.yml`|Playbook|Used to create yaml files from an existing AAP|
|`requirements.yml`|file|List of required ansible collections|
|`controller_config/ENVIRONNEMENT/common`|folder|Folder Containing global AAP settings|
|`configuration_templates`|folder|Folder containing templates that could be used to create resources|
|`collections`|folder|Folder containing collections used by the CaC playbooks|

## Prerequisites
- A properly configured Gitlab Environment (see procedure below)

### Protect The Branch

Follow the steps [in this link](https://si-devops-gitlab-ee.edf.fr/help/user/project/protected_branches.md#configure-a-protected-branch) to make your branch protected


### Gitlab Variables
The following Gitlab CICD Variables should be created :

#### Controller Variables 

|Variable|Example Value|Description|
|:---:|:---:|:---:|
|`CONTROLLER_CONFIG_DIR`|controller_config|The folder containing all the controller conf as code|
|`CONFIGURE_CONTROLLER`|true|Set to true to activate Controller configuration via Gitlab CICD Pipeline |
|`CONTROLLER_USERNAME`|gitops|AAP Controller user used by Gitlab Pipeline to connect to AAP Controller|
|`CONTROLLER_PASSWORD`|*****|AAP Controller user password|
|`CONTROLLER_HOST`|controller.company.com|AAP Controller Host|
|`CONTROLLER_VERIFY_SSL`|True|Set to true to activate Controller SSL certificates validation|

#### Automation Hub Variables
|Variable|Example Value|Description|
|:---:|:---:|:---:|
|`CONFIGURE_AH`|true|Set to true to activate Automation Hub configuration via Gitlab CICD Pipeline |
|`AH_CONFIG_DIR`|automationhub_config/|path to the automation hub configuration files|
|`AH_HOST`|automationhub.company.com|Automation Hub hostname or IP address
|`AH_USERNAME`|gitops|AAP Automation Hub user used by Gitlab Pipeline to connect to AAP Automation Hub|
|`AH_PASSWORD`|****|AAP Automation Hub user password|
|`AH_VERIFY_SSL`|True|Set to true to activate Automation Hub SSL certificates validation|
|`DOCKER_REGISTRY_USERNAME`|docker-user|Username of the remote container images registry hosting EE|
|`DOCKER_REGISTRY_PASSWORD`|****|Password of the remote container images registry|
|`PUB_AH_USERNAME`|redhat-user|Red Hat account username with access to Public Automation Hub|
|`PUB_AH_TOKEN`|****|Password of the Red Hat account with access to Public Automation Hub|

#### Pipeline Variables

|Variable|Example Value|Description|
|:---:|:---:|:---:|
|`CLEAN_ADMIN_OBJECTS`|true|Set to true to activate Admin Objects cleanup
